#include "mbed.h"
#include "HeptaBattery.h"

Serial pc(USBTX,USBRX);
HeptaBattery battery(p16,p26);

int main()
{
    pc.baud(9600);
    float bt;
    for(int i = 0; i < 10; i++) {
        battery.vol(&bt);
        pc.printf("Vol = %f\r\n",bt);
        wait(1.0);
    }
}